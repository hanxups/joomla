<?php

    //No direct acees to the file
    defined('_JEXEC') or die;

    use Joomla\Ldap\LdapClient;

    class PlgAuthenticationGrmap extends JPlugin
    {
        /**
         * Load the language file on instantiation. Note this is only available in Joomla 3.1 and higher.
         * If you want to support 3.0 series you must override the constructor
         *
         * @var    boolean
         * @since  3.1
         */
        // protected $autoloadLanguage = true;

        /**
         * Plugin method with the same name as the event will be called automatically.
         */
        function onUserAuthenticate( $credentials, $options, &$response )
        {
            /**
             * Joomla login system
             * 
             * 1. Check if user exists ==> value in $credentials['username']
             *      1.1 $credentials['username'] | $credentials['password'] check if they match on Db or Ldap AD
             * 2. If credentials are correct (LDAP or basic Joommla): 
             *      2.1 $email = JUser::getInstance($result); // Bring this in line with the rest of the system
             *          $response->email = $email->email;
             *          $response->status = JAuthentication::STATUS_SUCCESS;
             *          // Use this to log the user
             * 3. If credentials are not correct, use this:
             *      3.1 $response->status = JAuthentication::STATUS_FAILURE;
	         *          $response->error_message = 'Invalid username and password';
             */

            $response->type = 'Ldap';
            /*
            $ldap_host1     = ;
            $ldap_host2     = ;
            $ldap_host3     = ;
            $ldap_host4     = ;
            $ldap_filter    = ;
            $ldap_port      = ;
            $ldap_user      = ;
            $ldap_password  = ;
            $ldap_baseDN    = ;
            */
            # LDAP variables
            $ldap_host          = "ldap://192.168.1.172";  // your ldap servers
            $ldap_port          = 389;                 // your ldap server's port number
            $ldap_filter        = '(&(objectCategory=user)(memberOf=CN=JOOMLA_USERS,DC=mydomain,DC=local))';
            $ldap_user          = $credentials['username'];  //'user1'; //"CN=Administrator,CN=Users,DC=mydomain,DC=local";
            $ldap_password      = $credentials['password'];  //'User#123'; //"Admin#2018+1";
            $ldap_baseDN        = "DC=mydomain,DC=local";
            
            $ldap_filter = '(sAMAccountName='.$ldap_user.')';
            $ldap_attributes = 
            array(
                'displayName',      // Nome a mostra
                'sAMAccountName',   // Username
                'mail',             // Email lol
                'department',       // Departamento do user
                'memberOf'          // Grupo AD a que pertence
            );

            // Connecting to LDAP
            $ldap_conn = ldap_connect( $ldap_host, $ldap_port )
                or die( "Could not connect to $ldaphost" );
            ldap_set_option($ldap_conn, LDAP_OPT_PROTOCOL_VERSION, 3);
            // Connect to the AD with the given credentials
            $ldap_bind = ldap_bind( $ldap_conn, $ldap_user, $ldap_password );

            if($ldap_bind)
            {
                $ldap_search = ldap_search($ldap_conn, $ldap_baseDN, $ldap_filter, $ldap_attributes);
                $data_fetch = ldap_get_entries($ldap_conn, $ldap_search);
                $samaccountname_gm  = $data_fetch[0]['samaccountname'][0];
                $displayname_gm     = $data_fetch[0]['displayname'][0];
                $department_gm      = $data_fetch[0]['department'][0];
                $mail_gm            = $data_fetch[0]['mail'][0];

                // Chekc if AD user already exists on the Joomla platform
                $db = JFactory::getDbo();
                $query	= $db->getQuery(true)
                    ->select('id')
                    ->from('#__users')
                    ->where('username=' . $db->quote($credentials['username']));                    
                    $db->setQuery($query);
                    $result = $db->loadResult();

                if ($result) {
                    $response->status = JAuthentication::STATUS_SUCCESS;
                }
                else
                {
                    // User doesnt exists in Joomla platform and is created, with public access only
                    if(empty($mail_gm))
                    {
                        $mail_gm = $samaccountname_gm.'@joomlafakemail.com';
                    }
                    PlgAuthenticationGrmap::addJoomlaUser($displayname_gm, $samaccountname_gm, $ldap_password, $mail_gm);
                    $response->status = JAuthentication::STATUS_SUCCESS;

                    /*
                    //Check if user department exists in Joomla groups
                    // Get a db connection.
                    $db = JFactory::getDbo();

                    // Create a new query object.
                    $query = $db->getQuery(true);

                    // Query
                    $query = "SELECT COUNT(*) FROM `#__usergroups` WHERE `title` = '$department_gm' ";

                    //Does the query
                    $db->setQuery($query);

                    //Retrieves the results
                    $results = $db->loadAssocList();
                    if($results[0]['COUNT'] =='0')
                    {
                        // Create a new query object.
                        $query = $db->getQuery(true);

                        // Query
                        $query = "INSERT INTO `#__usergroups` (parent_id, lft, rgt, title) VALUES (1, 2, '$department_gm' ";

                        //Does the query
                        $db->setQuery($query);                    
                    }
                    */
                }
            }
            else
            {
                $response->status = JAuthentication::STATUS_FAILURE;
	            $response->error_message = 'Invalid username and password';
            }

        }

        public function addJoomlaUser($name, $username, $password, $email) 
        {
            jimport('joomla.user.helper');
            $data = array(
                "name"=>$name,
                "username"=>$username,
                "password"=>$password,
                "password2"=>$password,
                "email"=>$email,
                "block"=>0,
                "groups"=>array("1","2")
            );
            $user = new JUser;
            //Write to database
            if(!$user->bind($data)) {
                throw new Exception("Could not bind data. Error: " . $user->getError());
            }
            if(!$user->save()) {
                throw new Exception("Could not save user. Error: " . $user->getError());
            }
            return $user->id;
        }
    }

?>