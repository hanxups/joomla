<?php

/* 
    $user_info = JFactory::getUser();
    $file = fopen('test.txt','w');
    fwrite($file, $user_info.'\r\n');
    fclose($file);
    
*/

?>

<section id="content">
    <div class="row-fluid">
        <div id="sidebar" class="span2">
            <div class="sidebar-nav">
                <ul class="nav nav-list">
                    <li class="nav-header">
                        Painel de administração
                    </li>
                    <li class="divider"></li>
                    <li class="nav-header">Páginas</li>
                    <li  <?php if(basename(__FILE__)=='settings.php'){ echo 'class="active"'; } ?> >
                        <a href="index.php?option=com_groupmapping&amp;page=settings">Definições</a>
                    </li>
                    <li  <?php if(basename(__FILE__)=='ldap_settings.php'){ echo 'class="active"'; } ?> >
                        <a href="index.php?option=com_groupmapping&amp;page=ldap_settings">Definições LDAP</a>
                    </li>
                    <li  <?php if(basename(__FILE__)=='logs.php'){ echo 'class="active"'; } ?> >
                        <a href="index.php?option=com_groupmapping&amp;page=logs">Logs</a>
                    </li>
                    <li  <?php if(basename(__FILE__)=='mapping.php'){ echo 'class="active"'; } ?> >
                        <a href="index.php?option=com_groupmapping&amp;page=mapping">Mapeamento</a>
                    </li>
                    <li <?php if(basename(__FILE__)=='test.php'){ echo 'class="active"'; } ?> >
                        <a href="index.php?option=com_groupmapping&amp;page=test">Test</a>
                    </li>
                    <li <?php if(basename(__FILE__)=='test2.php'){ echo 'class="active"'; } ?> >
                        <a href="index.php?option=com_groupmapping&amp;page=test2">Test 2</a>
                    </li>
                </nav>
            </div>
        </div>
        <div class="span10">
            <fieldset class="form-horizontal">
                <legend>Testes</legend>
                <div class="control-group">
                    <div class="control-label">
                    <?php

                        //
                        include 'functions.php';

                        linkUserToGroup(655,11);
                    ?>

                    </div>
                    <div class="controls">
                    </div>
                </div>
        </div><!-- span10 -->
    </div><!-- row-fluid -->
</section>