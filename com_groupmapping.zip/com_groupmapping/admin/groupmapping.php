<?php //Hello from Administrator Group Mapping

    //Gets the database object and allows to query
    $db = JFactory::getDbo();
    $query = $db->getQuery(true);
    
    //var_dump($db);
    
    //Sets the page title
    //JFactory::getApplication()->input->set('hidemainmenu', true);
    JToolbarHelper::title(JText::_('LDAP | SSO and Group Mapping'), '');

    //JSubMenuHelper::addEntry('Morangos', 'the url to be launched on click on the item');

    // No direct access to this file
    defined('_JEXEC') or die('Restricted access');

    // Detects the page to display
    $display_page = '';
    if(isset($_GET['page']))
    {
        switch($_GET['page'])
        {
            // LDAP Settings file
            case 'ldap_settings':
                $display_page = 'groupmapping_ldap_settings.php';
                break;
                
            // User and Group Mapping file
            case 'mapping':
                $display_page = 'groupmapping_map.php';
                break;

            // General Settings file
            case 'settings':
                $display_page = 'groupmapping_settings.php';
                break;

            // Logs file viewer and settings
            case 'logs':
                $display_page = 'groupmapping_logs.php';
                break;

            // Test
            case 'test':
                $display_page = 'test.php';
                break;

            // Test2
            case 'test2':
                $display_page = 'test2.php';
                break;

            // Default value if nothing is specified
            default:
                //Is done to avoid tampering with the URL like ==> 'index.php?option=com_groupmapping?page=morangos'
                //$display_page = 'groupmapping_map.php';
                header('Location: index.php?option=com_groupmapping&page=mapping');
                break;
        }
    }
    else
    {
        // If no option is set on URL, redirects de Admin to the Mappings page
        header('Location: index.php?option=com_groupmapping&page=mapping');
    }

    //Display the Administration page file
    //include ($display_page);
   include($display_page);
    
?>