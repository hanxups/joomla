<section id="content">
    <div class="row-fluid">
        <div id="sidebar" class="span2">
            <div class="sidebar-nav">
                <ul class="nav nav-list">
                    <li class="nav-header">
                        Painel de administração
                    </li>
                    <li class="divider"></li>
                    <li class="nav-header">Páginas</li>
                    <li  <?php if(basename(__FILE__)=='settings.php'){ echo 'class="active"'; } ?> >
                        <a href="index.php?option=com_groupmapping&amp;page=settings">Definições</a>
                    </li>
                    <li  <?php if(basename(__FILE__)=='ldap_settings.php'){ echo 'class="active"'; } ?> >
                        <a href="index.php?option=com_groupmapping&amp;page=ldap_settings">Definições LDAP</a>
                    </li>
                    <li  <?php if(basename(__FILE__)=='logs.php'){ echo 'class="active"'; } ?> >
                        <a href="index.php?option=com_groupmapping&amp;page=logs">Logs</a>
                    </li>
                    <li  <?php if(basename(__FILE__)=='mapping.php'){ echo 'class="active"'; } ?> >
                        <a href="index.php?option=com_groupmapping&amp;page=mapping">Mapeamento</a>
                    </li>
                    <li <?php if(basename(__FILE__)=='test.php'){ echo 'class="active"'; } ?> >
                        <a href="index.php?option=com_groupmapping&amp;page=test">Test</a>
                    </li>
                </nav>
            </div>
        </div>
        <div class="span10">
            <fieldset class="form-horizontal">
                <legend>Configurador</legend>
                <div class="control-group">
                    <div class="control-label">
                        TARGET_HOSTS
                    </div>
                    <div class="controls">
                        <input type="text" name="target_host_1" class="required" size="50" value=""placeholder="ldaps://mydomain.server"/>
                        <input type="text" name="target_host_2" class="required" size="50" value="" placeholder="ldaps://mydomain.server"/>
                        <input type="text" name="target_host_3" class="required" size="50" value="" placeholder="ldaps://mydomain.server"/>
                        <input type="text" name="target_host_4" class="required" size="50" value="" placeholder="ldaps://mydomain.server"/>
                    </div>

                    <hr>
                    <div class="control-label">
                        LOG_FS_NAME
                    </div>
                    <div class="controls">
                        <input type="text" name="log_fs_name" class="required" size="50" value="" placeholder="ldaps://mydomain.server"/>
                    </div>

                    <hr>
                    <div class="control-label">
                        LOG_T_WINDOW
                    </div>
                    <div class="controls">
                        <input type="number" name="" class="required" size="50" value="" placeholder="dias"/>
                    </div>

                    <hr>
                    <div class="control-label">
                        LOG_DETAIL
                    </div>
                    <div class="controls">
                        <select name="" class="required" placeholder="">
                            <option value="MIN">MIN</option>
                            <option value="STD" selected>STD</option>
                            <option value="MAX">MAX</option>
                        </select>
                    </div>

                </div>
            <fieldset class="form-horizontal">            
            <br>            
            <fieldset class="form-horizontal">
                <legend>Configuração LDAP</legend>
                <div class="control-group">

                    <div class="control-label">
                        TARGET_HOSTS
                    </div>
                    <div class="controls">
                        <input type="text" name="target_host_1" class="required" size="50" value=""placeholder="ldaps://mydomain.server"/>
                        <input type="text" name="target_host_2" class="required" size="50" value="" placeholder="ldaps://mydomain.server"/>
                        <input type="text" name="target_host_3" class="required" size="50" value="" placeholder="ldaps://mydomain.server"/>
                        <input type="text" name="target_host_4" class="required" size="50" value="" placeholder="ldaps://mydomain.server"/>
                    </div>

                    <hr>
                    <div class="control-label">
                        PORT
                    </div>
                    <div class="controls">
                        <input type="number" name="ldap_port" class="required" />
                    </div>

                    <hr>
                    <div class="control-label">
                        USE_V3
                    </div>
                    <div class="controls">
                        <input type="checkbox" name="use_v3" class="required" />
                    </div>

                    <hr>
                    <div class="control-label">
                        PROXY_USERNAME
                    </div>
                    <div class="controls">
                        <input type="text" name="proxy_username" class="required" />
                    </div>

                    <hr>
                    <div class="control-label">
                        PROXY_USER_PASSWORD
                    </div>
                    <div class="controls">
                        <input type="password" name="proxy_password" class="required" />
                    </div>

                    <hr>
                    <div class="control-label">
                        PROXY_ENCRYPTION
                    </div>
                    <div class="controls">
                        <input type="number" name="proxy_encryption" class="required" />
                    </div>

                        <hr>
                    <div class="control-label">
                        BASE_DN
                    </div>
                    <div class="controls">
                        <input type="text" name="proxy_encryption" class="required" placeholder="Example : DC=mydomain,DC=local"/>
                    </div>

                        <hr>
                    <div class="control-label">
                        USER_QUERY
                    </div>
                    <div class="controls">
                        <input type="text" name="user_query" class="required" placeholder="Example :  (sAMAccountName=[username])" />
                    </div>

                        <hr>
                    <div class="control-label">
                        USER_ID
                    </div>
                    <div class="controls">
                        <input type="text" name="proxy_encryption" class="required" placeholder="Example : sAMAccountName"/>
                    </div>

                        <hr>
                    <div class="control-label">
                        FULL_NAME
                    </div>
                    <div class="controls">
                        <input type="text" name="proxy_encryption" class="required" placeholder="Exameple : displayName" />
                    </div>

                        <hr>
                    <div class="control-label">
                        EMAIL
                    </div>
                    <div class="controls">
                        <input type="text" name="proxy_encryption" class="required" placeholder="Exameple : mail" />
                    </div>

                        <hr>
                    <div class="control-label">
                        PASSWORD
                    </div>
                    <div class="controls">
                        <input type="text" name="proxy_encryption" class="required" placeholder="Exameple : userPassword" />
                    </div>

                        <hr>
                    <div class="control-label">
                        PASSWORD_HASH
                    </div>
                    <div class="controls">
                        <input type="number" name="proxy_encryption" class="required" placeholder="Exameple : " />
                    </div>

                        <hr>
                    <div class="control-label">
                        PASSWORD_PREFIX
                    </div>
                    <div class="controls">
                        <input type="number" name="proxy_encryption" class="required" placeholder="Exameple : 0"  />
                    </div>

                        <hr>
                    <div class="control-label">
                        ALL_USER_FILTER
                    </div>
                    <div class="controls">
                        <input type="text" name="all_user_filter" class="required" placeholder="Exameple : (objectClass=person)"  />
                    </div>
                    
                    <hr>
                    <div class="control-label">
                        DEPARTMENT_FILTER
                    </div>
                    <div class="controls">
                        <input type="text" name="department_filter" class="required" placeholder="Exameple : (objectClass=person)"  />
                    </div>

                    <hr>
                    <div class="control-label">
                        Por inserir : Configurações SMTP do email para enviar os emails em determinados eventos
                    </div>
                    <div class="controls">
                        <input type="text" name="department_filter" class="required" placeholder="Exameple : (objectClass=person)"  />
                    </div>


                    <br>
                    <div class="controls">
                        <input type="submit" class="btn btn-small button-apply btn-success" value="Guardar alterações" /> 
                        </div>                            
                    </div>                        
            </fieldset>
        </div><!-- span10 -->
    </div><!-- row-fluid -->
</section>