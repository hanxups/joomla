<?php
    echo "<br>Inside  : groupmapping_ldap_settings.php <br>";
?>

<a href="index.php?option=com_groupmapping&page=settings">
    <button>General Settings</button>
</a>
<a href="index.php?option=com_groupmapping&page=ldap_settings">
    <button>LDAP Settings</button>
</a>
<a href="index.php?option=com_groupmapping&page=logs">
    <button>Logs</button>
</a>
<a href="index.php?option=com_groupmapping&page=mapping">
    <button>Mapping</button>
</a>