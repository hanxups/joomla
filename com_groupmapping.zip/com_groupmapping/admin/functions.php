<?php

    function addAccessViewLevels($article_id, $group_id)
    {
        /**
         * Receives artilce_id and group_id and creates a new
         * access view for that group
         */

        // Get a db connection.
        $db = JFactory::getDbo();

        // Create a new query object.
        $query = $db->getQuery(true);

        // Check if the content already has a rule by article_id from #__content
        $query
            ->select($db->quoteName('*'))
            ->from($db->quoteName('#__viewlevels'))
            ->where($db->quoteName('id').' = '.$db->quote($article_id));

        //Does the query
        $db->setQuery($query);

        //Retrieves the results
        $results = $db->loadAssocList();

        /*
        echo '<br> Printing results from query<br>';
        echo '<br> ID : '       . $results[0]['id'];
        echo '<br> Title : '    . $results[0]['title'];
        echo '<br> Ordering : ' . $results[0]['ordering'];
        echo '<br> Rules : '    . $results[0]['rules'];
        */

        // Adds new id to the values
        $json_decoded = json_decode($results[0]['rules']);
        array_push($json_decoded, $group_id);
        $string_to_store = '[';
        $max = sizeof($json_decoded);
        for ($i=0; $i < $max; $i++)
        {
            if($i==0)
            {
                $string_to_store .= $json_decoded[$i];
            }
            else
            {
                $string_to_store .= ',' . $json_decoded[$i];
            }
        }
        $string_to_store .= ']';

        // Updates database with new values
        $query = "UPDATE #__viewlevels SET rules='$string_to_store' WHERE id='$article_id' ";
        
        $db->setQuery($query);
        $result = $db->execute();                            
    } // addAccessViewLevels

    function linkUserToGroup($user_id, $group_id)
    {
        /**
         * 
         */

        // Get a db connection.
        $db = JFactory::getDbo();

        // Create a new query object.
        $query = $db->getQuery(true);

        // Check if the content already has a rule by article_id from #__content
        $query = " SELECT COUNT(*) FROM `#__user_usergroup_map` WHERE user_id='$user_id' AND group_id='$group_id' ";

        //Does the query
        $db->setQuery($query);

        //Retrieves the results
        $results = $db->loadAssocList();

        if($results[0]['COUNT(*)']=='0')
        {
            // Get a db connection.
            $db = JFactory::getDbo();

            // Create a new query object.
            $query = $db->getQuery(true);

            // Check if the content already has a rule by article_id from #__content
            $query = " INSERT INTO `#__user_usergroup_map` (user_id, group_id) VALUES ('$user_id', '$group_id') ";

            // Does the query
            $db->setQuery($query);
            $db->execute();
        }
        else
        {
            echo "<br> O utilizador ja esta associado a esse grupo";
        }
    } // linkUserToGroup

?>